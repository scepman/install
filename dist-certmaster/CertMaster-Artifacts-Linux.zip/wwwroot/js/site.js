﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

function createCustomXhr() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 2) { // "HEADERS_RECEIVED" — the response status and headers are available. At this point, you can check xhr.status (e.g., 200 vs 400) and decide whether to expect a blob or text response.
            if (xhr.status === 200) {
                xhr.responseType = 'blob'; // binary success
            } else {
                xhr.responseType = 'text'; // error JSON as text
            }
        }
    };
    return xhr;
}

failedIssueCertificateAjax = function (xhr) {
    enableRequestCertificateForm();

    let response = null;
    try {
        response = xhr.responseJSON || JSON.parse(xhr.responseText);
    } catch (e) {
        // Not JSON, fallback to generic error
    }

    if (response && response.errors) {
        let messages = [];
        for (let key in response.errors) {
            if (response.errors.hasOwnProperty(key)) {
                messages = messages.concat(response.errors[key]);
            }
        }
        if (messages.length > 0) {
            toastr.warning(messages.join('<br/>'), 'Validation Error', { timeOut: 0, extendedTimeOut: 0 });
            return;
        }
    }

    // Fallback: generic error
    toastr.warning('Something has gone wrong while issuing the certificate. Please check the logs for more details. You can also try again.', '', { timeOut: 0, extendedTimeOut: 0 });
};

successIssueCertificateAjax = function (blob, status, xhr) {
    var filename = "";
    var disposition = xhr.getResponseHeader('Content-Disposition');
    if (disposition && disposition.indexOf('attachment') !== -1) {
        var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
        var matches = filenameRegex.exec(disposition);
        if (matches != null && matches[1]) filename = matches[1].replace(/['"]/g, '');
    }

    if (typeof window.navigator.msSaveBlob !== 'undefined') {
        // IE workaround for "HTML7007: One or more blob URLs were revoked by closing the blob for which they were created. These URLs will no longer resolve as the data backing the URL has been freed."
        window.navigator.msSaveBlob(blob, filename);
    } else {
        var URL = window.URL || window.webkitURL;
        var downloadUrl = URL.createObjectURL(blob);

        if (filename) {
            // use HTML5 a[download] attribute to specify filename
            var a = document.createElement("a");
            // safari doesn't support this yet
            if (typeof a.download === 'undefined') {
                window.location = downloadUrl;
            } else {
                a.href = downloadUrl;
                a.download = filename;
                document.body.appendChild(a);
                a.click();
            }
        } else {
            window.location = downloadUrl;
        }

        setTimeout(function () { URL.revokeObjectURL(downloadUrl); }, 100); // cleanup
    }
    toastr.success("Certificate is generated and downloaded to the file system");
}

setResponseTypeBeforeSendingRequest = function (xhr, settings) {
    settings.xhr = createCustomXhr;
}

$(document).ajaxStart(function () {
    $.LoadingOverlay("show", {
        background: "rgba(255, 255, 255, 0.3)",
        image: "",
        fontawesomeColor: "#609ad4",
        size: "10",
        fontawesome: "fas fa-circle-notch fa-xs fa-spin"
    });
});

$(document).ajaxComplete(function () {
    $.LoadingOverlay("hide");
});

window.addEventListener('load', function () {
    enableFormOnInputChanges();
    // Initialize email addresses visibility based on Email Protection EKU selection
    initializeEmailAddressesVisibility();
}, false);

enableFormOnInputChanges = function () {
    getRequestCertificateForm($(this)).on("input", function () {
        enableRequestCertificateForm();
    });
}

enableRequestCertificateForm = function() {
    if ($('.disableSubmitButtonOnFormSubmit').prop('disabled')) {
        $('.disableSubmitButtonOnFormSubmit').prop('disabled', false);
    }
}

getRequestCertificateForm = function (currentElement) {
    let submitButtonToDisableForm = currentElement.parents('form');
    if (submitButtonToDisableForm.length === 0) {
        var submitButtonToDisableFormName = $('.disableSubmitButtonOnFormSubmit').attr('form')
        submitButtonToDisableForm = $(`#${submitButtonToDisableFormName}`);
    }
    return submitButtonToDisableForm;
}

$(document)
  .off('click.certificateSubmit', '.disableSubmitButtonOnFormSubmit')
  .on('click.certificateSubmit', '.disableSubmitButtonOnFormSubmit', function (e) {
      e.preventDefault();
      if ($(this).prop('disabled')) return;
      const form = getRequestCertificateForm($(this));
      if (form.valid()) {
          $(this).prop('disabled', true);
          form.trigger('submit');
      }
  });

// Function to check if Email Protection EKU is selected and toggle email addresses visibility
function toggleEmailAddressesVisibility() {
    var emailProtectionSelected = false;
    
    // Email Protection OID is 1.3.6.1.5.5.7.3.4 - look for either the label text or hidden value
    $('.eku-multicheckbox-input').each(function() {
        var $checkbox = $(this);
        var $label = $checkbox.next('label');
        var $valueInput = $checkbox.siblings('input[type="hidden"]').filter(function() {
            return $(this).attr('name') && $(this).attr('name').indexOf('Value') > -1;
        });
        
        // Check if this is the Email Protection EKU by looking at either the label text or the hidden value
        var isEmailProtection = $label.text().trim() === 'Email Protection' || 
                               ($valueInput.length > 0 && $valueInput.val() === '1.3.6.1.5.5.7.3.4');
        
        if (isEmailProtection && $checkbox.is(':checked') && !$checkbox.is(':disabled')) {
            emailProtectionSelected = true;
            return false; // Break out of the loop
        }
    });
    
    // Show or hide the email addresses row based on selection
    var $emailRow = $('#email-addresses-row');
    if (emailProtectionSelected) {
        $emailRow.slideDown(300);
    } else {
        $emailRow.slideUp(300);
    }
}

// Initialize email addresses visibility and set up change handlers
function initializeEmailAddressesVisibility() {
    // Set initial visibility
    toggleEmailAddressesVisibility();
    
    // Add change event listeners to all EKU checkboxes
    $(document).on('change', '.eku-multicheckbox-input', function() {
        toggleEmailAddressesVisibility();
    });
}

// Unified Bootstrap Collapse functionality for both Bootstrap 4 and 5
function handleCollapseToggle(element) {
    var target = $(element).attr('data-target') || $(element).attr('data-bs-target');
    var $target = $(target);
    
    if ($target.length) {
        if ($target.hasClass('show')) {
            // Hide the collapse
            $target.removeClass('show').slideUp(300);
            $(element).addClass('collapsed');
            $(element).attr('aria-expanded', 'false');
        } else {
            // Show the collapse
            $target.addClass('show').slideDown(300);
            $(element).removeClass('collapsed');
            $(element).attr('aria-expanded', 'true');
        }
    }
}

// Bootstrap 4 style collapse (data-toggle="collapse")
$(document).on('click', '[data-toggle="collapse"]', function (e) {
    e.preventDefault();
    handleCollapseToggle(this);
});

// Bootstrap 5 style collapse (data-bs-toggle="collapse")
$(document).on('click', '[data-bs-toggle="collapse"]', function (e) {
    e.preventDefault();
    handleCollapseToggle(this);
});