﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

failedAjax = function (xhr) {
    toastr.warning('Something has gone wrong while issuing the certificate. Please check the logs for more details. You can also try again.', '', { timeOut: 0, extendedTimeOut: 0 })
};

$(document).ajaxStart(function () {
    $.LoadingOverlay("show", {
        background: "rgba(255, 255, 255, 0.3)",
        image: "",
        fontawesomeColor: "#609ad4",
        size: "10",
        fontawesome: "fas fa-circle-notch fa-xs fa-spin"
    });
});

$(document).ajaxStop(function () {
    $.LoadingOverlay("hide");
});