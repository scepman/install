function initEkuMulticheckboxValidation() {
    // Only attach to checkboxes with the class 'eku-multicheckbox-input'
    $('input[type=checkbox].eku-multicheckbox-input').on('change', function () {
        if ($('input[type=checkbox].eku-multicheckbox-input:checked').length > 0) {
            $('#ExtendedKeyUsageList-error').addClass('d-none');
        }
    });

    $('button[type="submit"]').on('click', function () {
        // Get the form name from the 'form' attribute of the button
        var formName = $(this).attr('form');
        if (!formName) return true; // No form attribute, do not trigger validation

        var $form = $('#' + formName);
        if ($form.length === 0) return true; // Form not found, do not trigger validation

        if ($('input[type=checkbox].eku-multicheckbox-input').length > 0) {
            // Only validate checkboxes with the class 'eku-multicheckbox-input'
            if ($('input[type=checkbox].eku-multicheckbox-input:checked').length === 0) {
                $('#ExtendedKeyUsageList-error').removeClass('d-none');
                $form.valid();
                return false;
            }
            else if ($('input[type=checkbox].eku-multicheckbox-input:checked').length > 0) {
                $('#ExtendedKeyUsageList-error').addClass('d-none');
            }
        }
    });
}

$(function () {
    window.addEventListener('load', function () {
        initEkuMulticheckboxValidation();
    }, false);
}(jQuery));